#!/bin/bash

#run-webcontrolA.sh

docker run -d -e "VIRTUAL_HOST=foo1.bar.de" \
              -e "VIRTUAL_PORT=443" \
              -e "VIRTUAL_PROTO=https" \
              -e "LETSENCRYPT_HOST=foo1.bar.de" \
              -e "LETSENCRYPT_EMAIL=your@email.here" \
              -e "LETSENCRYPT_TEST=true" \
              --expose 443 -p 34290-34299:34290-34299/udp \
              -v /srv/webcontrol/configA/:/tmp/host \
              --name webcontrolA mowfax/factoriowebcontrol:latest

