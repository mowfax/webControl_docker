#!/bin/bash

#run-webcontrolB.sh

docker run -d -e "VIRTUAL_HOST=foo2.bar.de" \
              -e "VIRTUAL_PORT=443" \
              -e "VIRTUAL_PROTO=https" \
              -e "LETSENCRYPT_HOST=foo2.bar.de" \
              -e "LETSENCRYPT_EMAIL=your@email.here" \
              --expose 443 -p 34390-34399:34290-34299/udp \
              -v /srv/webcontrol/configB/:/tmp/host \
              --restart unless-stopped \
              --name webcontrolB mowfax/factoriowebcontrol:latest

