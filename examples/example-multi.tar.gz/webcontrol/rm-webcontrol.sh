#!/bin/bash

#rm-webcontrol.sh

docker stop webcontrolA
docker stop webcontrolB
docker rm webcontrolA
docker rm webcontrolB

