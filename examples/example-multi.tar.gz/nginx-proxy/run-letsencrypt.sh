#!/bin/bash

#run-letsencrypt.sh

docker run -d --name letsencrypt \
              -v /srv/nginx-proxy/certs:/etc/nginx/certs:rw \
              -v /var/run/docker.sock:/var/run/docker.sock:ro \
              --volumes-from nginx-proxy \
              --restart unless-stopped \
              jrcs/letsencrypt-nginx-proxy-companion

