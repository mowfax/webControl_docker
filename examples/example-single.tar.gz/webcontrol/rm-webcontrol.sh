#!/bin/bash

#rm-webcontrol.sh

docker stop webcontrol
docker rm webcontrol

