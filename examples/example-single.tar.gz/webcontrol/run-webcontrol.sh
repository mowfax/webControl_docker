#!/bin/bash

#run-webcontrol.sh

docker run -d -p 443:443/tcp -p 34290-34299:34290-34299/udp \
              -v /srv/webcontrol/config/:/tmp/host \
              -v /srv/webcontrol/server1:/var/www/factorio/server1 \
              -v /srv/webcontrol/server2:/var/www/factorio/server2 \
              --restart unless-stopped \
              --name webcontrol mowfax/factoriowebcontrol:latest

